var searchData=
[
  ['target',['target',['../classCDataSend.html#a2caccd5f4aaa917672b589405a158277',1,'CDataSend']]],
  ['tau',['tau',['../classCDataGenerator__Peak.html#a50820b7de1819c232e336651718dadb3',1,'CDataGenerator_Peak']]],
  ['threshold',['threshold',['../classCDataProcessor__Max__Min.html#a7c5d1b7b0835eede985a4b52f172f411',1,'CDataProcessor_Max_Min::threshold()'],['../classCDataProcessor__Trapeze.html#af545ac3ef0e5848fa2d10070344403a7',1,'CDataProcessor_Trapeze::threshold()'],['../classCDataProcessorGPU__discri__opencl.html#a5d00df0bd0353852262ec34e873c1e9c',1,'CDataProcessorGPU_discri_opencl::threshold()']]],
  ['ti',['Ti',['../classCDataProcessor__Max__Min.html#ac5840be7492ff1e133a88eccfaac9f2b',1,'CDataProcessor_Max_Min']]],
  ['tm',['Tm',['../classCDataProcessor__Trapeze.html#a041d3589ede0e1506800af1d4cf252f7',1,'CDataProcessor_Trapeze::Tm()'],['../classCDataProcessorGPU__discri__opencl.html#ae8dc01853be91bad252a769a9717750f',1,'CDataProcessorGPU_discri_opencl::Tm()']]],
  ['tn',['tn',['../classCBaseOMPLock.html#a84ec93ca3270158a8d6808e3426df3bf',1,'CBaseOMPLock']]],
  ['trapeze',['trapeze',['../classCDataProcessor__Trapeze.html#ad0f7b2595d795e582c9070ac4f10a14d',1,'CDataProcessor_Trapeze::trapeze()'],['../classCDataProcessorGPU__discri__opencl.html#a01c5bc1bac5ed2bf211649a7b8cda3df',1,'CDataProcessorGPU_discri_opencl::trapeze()']]]
];

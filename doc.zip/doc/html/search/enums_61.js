var searchData=
[
  ['access_5fstatus_5for_5fstate',['ACCESS_STATUS_OR_STATE',['../classCDataAccess.html#a6c8d0909028ca12079393c5ffa0deb83',1,'CDataAccess']]]
];

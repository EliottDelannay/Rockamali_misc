var searchData=
[
  ['savefile',['saveFile',['../structCParameterNetCDF.html#a10f859acba9ceba1cc712b52028df93b',1,'CParameterNetCDF']]],
  ['savenetcdffile',['saveNetCDFFile',['../classCImgNetCDF.html#a94e05ac95caf702c89b9d9344836d425',1,'CImgNetCDF::saveNetCDFFile(char *fileName, std::vector&lt; std::string &gt; *pDim_names=NULL, std::string *pTime_name=NULL)'],['../classCImgNetCDF.html#ac71ad9414c16aab2dec51065b756c661',1,'CImgNetCDF::saveNetCDFFile(char *fileName, NcFile::FileMode fmod, std::vector&lt; std::string &gt; *pDim_names=NULL, std::string *pTime_name=NULL)'],['../classCImgNetCDF__test.html#a8700c63eb0460ff2335a99d85420d579',1,'CImgNetCDF_test::saveNetCDFFile()']]],
  ['set_5fstatus',['set_status',['../classCAccessOMPLock.html#a18c370c35f1f99cd6e6fab894d731965',1,'CAccessOMPLock']]],
  ['setdefaultunitname',['setDefaultUnitName',['../structCParameterNetCDF.html#acb582d5ae787676737bffd61baa7709e',1,'CParameterNetCDF']]],
  ['setdefaultvarname',['setDefaultVarName',['../structCParameterNetCDF.html#ae715f6279bd27eac6402fe1f103c8944',1,'CParameterNetCDF']]],
  ['setfile',['setFile',['../structCParameterNetCDF.html#a49b61af0226a2ee2d9e3587be9407ece',1,'CParameterNetCDF']]],
  ['setnetcdfdims',['setNetCDFDims',['../classCImgNetCDF.html#a869e6e6d150c88e139f4fc97fcf086c8',1,'CImgNetCDF::setNetCDFDims(std::string &amp;dim_names, NcDim *pNetCDFDimt=NULL)'],['../classCImgNetCDF.html#a4d60272a959fcdae94b83f46cf5a2864',1,'CImgNetCDF::setNetCDFDims(std::vector&lt; NcDim * &gt; VDim, NcDim *pNetCDFDimt=NULL)']]],
  ['setnetcdffile',['setNetCDFFile',['../classCImgNetCDF.html#a8b20f921fe15b013c7b16a21d244bad7',1,'CImgNetCDF']]],
  ['show_5fchecking',['show_checking',['../classCDataProcessor.html#a9b09d4196c33261555a80136e484185f',1,'CDataProcessor::show_checking()'],['../classCDataReceive.html#ad245a5b0c5427f3957e2b0d58630bfc2',1,'CDataReceive::show_checking()']]],
  ['show_5ffactory_5ftypes',['show_factory_types',['../classCDataGenerator__factory.html#a910599659b09c66fee0d97b18fa8debb',1,'CDataGenerator_factory::show_factory_types()'],['../classCDataProcessorCPU__factory.html#a414cced36568b562cabd54e090490910',1,'CDataProcessorCPU_factory::show_factory_types()'],['../classCDataProcessorGPUfactory.html#a357badccc86dfeb34206bbcfbbecfbe5',1,'CDataProcessorGPUfactory::show_factory_types()']]]
];

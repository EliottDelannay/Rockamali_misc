var searchData=
[
  ['unit_5fname',['unit_name',['../classCDataStore.html#ad16f85efd6d4c99a0f0c9f9d15425bcc',1,'CDataStore']]],
  ['unit_5fnames',['unit_names',['../classCDataGenerator__Peak.html#a972e7dd4b9616b6ddbdfee3b3a9bf9d6',1,'CDataGenerator_Peak']]]
];

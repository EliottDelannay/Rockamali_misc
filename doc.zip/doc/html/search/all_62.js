var searchData=
[
  ['b',['B',['../classCDataGenerator__Peak.html#a5b48ca23ad4228221c3ab1dd4d88fd46',1,'CDataGenerator_Peak::B()'],['../classCDataProcessor__Max__Min.html#a083b5cde7261f36679e1e2de887eda6a',1,'CDataProcessor_Max_Min::B()']]],
  ['boost_5fcompute_5ffunction',['BOOST_COMPUTE_FUNCTION',['../classCDataProcessorGPU__function__macro.html#a0b73c6b4f18350c71c6e1ef5f5dcf824',1,'CDataProcessorGPU_function_macro']]],
  ['buffer_5f',['buffer_',['../classudp__server.html#a63c11b837825399ed6c02c9a58a38526',1,'udp_server']]],
  ['bug_20list',['Bug List',['../bug.html',1,'']]]
];

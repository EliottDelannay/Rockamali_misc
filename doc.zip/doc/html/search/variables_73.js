var searchData=
[
  ['s',['s',['../classCDataProcessor__Trapeze.html#a83b28595b3d990b86991bdfce00130d5',1,'CDataProcessor_Trapeze::s()'],['../classCDataProcessor__dilate.html#a60c9cc1ee760e5067f6d7f3ff4859b73',1,'CDataProcessor_dilate::s()'],['../classCDataReceive.html#ac8de317b11f88c9680e32e7eb7bb1f1c',1,'CDataReceive::s()']]],
  ['sender_5f',['sender_',['../classudp__server.html#a23cd04e1e4a7a781226b4841439f4ad3',1,'udp_server']]],
  ['servers',['servers',['../classCDataReceive.html#aae5735cbe0220ce14099677db7ef90de',1,'CDataReceive']]],
  ['set_5fstatus',['set_status',['../classCDataBuffer.html#a89f6e10ecc7c8f6adbc5cbb147753e6d',1,'CDataBuffer']]],
  ['set_5fstatusr',['set_statusR',['../classCDataProcessor.html#a4161e116e2ce7b69c8408a10772bb4de',1,'CDataProcessor']]],
  ['socket',['socket',['../classCDataSend.html#a5f9298e64c2175c99a312ffcfd43a588',1,'CDataSend']]],
  ['socket_5f',['socket_',['../classudp__server.html#ab22c6ed20b4b67d21cef7863dd33f42c',1,'udp_server']]],
  ['source_5fwith_5ftemplate',['source_with_template',['../classCDataProcessorGPU__opencl__template.html#a03efabd724a00de2afa5424000cb2ec2',1,'CDataProcessorGPU_opencl_template']]],
  ['space_5f',['space_',['../classallocator.html#aeba81de80f6fdfa69f293e403022c01f',1,'allocator']]],
  ['string',['string',['../structarguments.html#a9b29d1546550a090feb7c6b6ff5920ed',1,'arguments']]]
];

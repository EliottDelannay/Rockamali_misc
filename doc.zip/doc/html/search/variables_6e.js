var searchData=
[
  ['n',['n',['../classCDataProcessor__Trapeze.html#a8d62b1baa235d137d06c4420284ee769',1,'CDataProcessor_Trapeze::n()'],['../classCDataProcessorGPU__discri__opencl.html#a6f4d896a1fd55b785dd0f47060c5003f',1,'CDataProcessorGPU_discri_opencl::n()']]],
  ['nb_5fta',['nb_tA',['../classCDataGenerator__Peak.html#a2874940c8edf0ad5bfd0ff30d6de0e87',1,'CDataGenerator_Peak']]],
  ['nb_5ftb',['nb_tB',['../classCDataGenerator__Peak.html#a1cf96c165f0458034deae2f1b09474b2',1,'CDataGenerator_Peak']]],
  ['nc',['nc',['../classCDataGenerator__Peak.html#a431eb29cb67d451bca514a8f93268ab8',1,'CDataGenerator_Peak::nc()'],['../classCDataStore.html#a2ce389cec6583318b044e9d8f29c67f7',1,'CDataStore::nc()']]],
  ['nc_5fimg',['nc_img',['../classCDataGenerator__Peak.html#ac6faa28cf170fb31542f479fc136f32e',1,'CDataGenerator_Peak::nc_img()'],['../classCDataStore.html#ad525d25278f5dda2cb3576a7f5903153',1,'CDataStore::nc_img()']]]
];

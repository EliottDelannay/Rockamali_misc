var searchData=
[
  ['nc_5ferror',['NC_ERROR',['../NetCDFinfo_8h.html#a748bed9403c1a403234a94de0ec67669',1,'NC_ERROR():&#160;NetCDFinfo.h'],['../CImg__NetCDF_8h.html#a748bed9403c1a403234a94de0ec67669',1,'NC_ERROR():&#160;CImg_NetCDF.h']]],
  ['netcdf_5ftype_5finfo_5fversion',['NETCDF_TYPE_INFO_VERSION',['../NetCDFinfo_8h.html#a770d31ec7fb29f478df84ef533107639',1,'NetCDFinfo.h']]]
];

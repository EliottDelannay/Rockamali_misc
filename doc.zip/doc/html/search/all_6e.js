var searchData=
[
  ['n',['n',['../classCDataProcessor__Trapeze.html#a8d62b1baa235d137d06c4420284ee769',1,'CDataProcessor_Trapeze::n()'],['../classCDataProcessorGPU__discri__opencl.html#a6f4d896a1fd55b785dd0f47060c5003f',1,'CDataProcessorGPU_discri_opencl::n()']]],
  ['nb_5fta',['nb_tA',['../classCDataGenerator__Peak.html#a2874940c8edf0ad5bfd0ff30d6de0e87',1,'CDataGenerator_Peak']]],
  ['nb_5ftb',['nb_tB',['../classCDataGenerator__Peak.html#a1cf96c165f0458034deae2f1b09474b2',1,'CDataGenerator_Peak']]],
  ['nc',['nc',['../classCDataGenerator__Peak.html#a431eb29cb67d451bca514a8f93268ab8',1,'CDataGenerator_Peak::nc()'],['../classCDataStore.html#a2ce389cec6583318b044e9d8f29c67f7',1,'CDataStore::nc()']]],
  ['nc_5ferror',['NC_ERROR',['../NetCDFinfo_8h.html#a748bed9403c1a403234a94de0ec67669',1,'NC_ERROR():&#160;NetCDFinfo.h'],['../CImg__NetCDF_8h.html#a748bed9403c1a403234a94de0ec67669',1,'NC_ERROR():&#160;CImg_NetCDF.h']]],
  ['nc_5fimg',['nc_img',['../classCDataGenerator__Peak.html#ac6faa28cf170fb31542f479fc136f32e',1,'CDataGenerator_Peak::nc_img()'],['../classCDataStore.html#ad525d25278f5dda2cb3576a7f5903153',1,'CDataStore::nc_img()']]],
  ['ncid',['ncId',['../structNcTypeInfo.html#a1dae1b571ad26d0449624a5a9b82a94d',1,'NcTypeInfo::ncId()'],['../structNcTypeInfo_3_01char_01_4.html#a793fd6db83de36e128967f1be566d2f1',1,'NcTypeInfo&lt; char &gt;::ncId()'],['../structNcTypeInfo_3_01int_01_4.html#a58b02b7854ab79551b2c7f7c5bc88b10',1,'NcTypeInfo&lt; int &gt;::ncId()'],['../structNcTypeInfo_3_01float_01_4.html#aa2cbe486326bc347db7fc33211e75a50',1,'NcTypeInfo&lt; float &gt;::ncId()'],['../structNcTypeInfo_3_01double_01_4.html#af898cbc1b24de3ac4f6584d33a2e72a2',1,'NcTypeInfo&lt; double &gt;::ncId()'],['../structNcTypeInfo_3_01bool_01_4.html#ab59366c3666b62095881e9b4fa541068',1,'NcTypeInfo&lt; bool &gt;::ncId()'],['../structNcTypeInfo_3_01ncbyte_01_4.html#a14463071e68f6f80af65f413c23d1204',1,'NcTypeInfo&lt; ncbyte &gt;::ncId()']]],
  ['ncstr',['ncStr',['../structNcTypeInfo.html#ae2b75d7fb29937cf540fc4b0d5af1401',1,'NcTypeInfo::ncStr()'],['../structNcTypeInfo_3_01char_01_4.html#aad2937b2997431971108a566df411128',1,'NcTypeInfo&lt; char &gt;::ncStr()'],['../structNcTypeInfo_3_01int_01_4.html#a067aaca09704450a2d0479624b733d86',1,'NcTypeInfo&lt; int &gt;::ncStr()'],['../structNcTypeInfo_3_01float_01_4.html#a32293ea5dfc5c25cdc7c3d60e85c2a34',1,'NcTypeInfo&lt; float &gt;::ncStr()'],['../structNcTypeInfo_3_01double_01_4.html#a35ae5e7e1cb9b0b2c1ee67b64218be7f',1,'NcTypeInfo&lt; double &gt;::ncStr()'],['../structNcTypeInfo_3_01bool_01_4.html#a4f1499a295b6d8fa51c0ab93da497407',1,'NcTypeInfo&lt; bool &gt;::ncStr()'],['../structNcTypeInfo_3_01ncbyte_01_4.html#a76cd975da2455496902556bbd10be7c8',1,'NcTypeInfo&lt; ncbyte &gt;::ncStr()']]],
  ['nctypeinfo',['NcTypeInfo',['../structNcTypeInfo.html',1,'']]],
  ['nctypeinfo_3c_20bool_20_3e',['NcTypeInfo&lt; bool &gt;',['../structNcTypeInfo_3_01bool_01_4.html',1,'']]],
  ['nctypeinfo_3c_20char_20_3e',['NcTypeInfo&lt; char &gt;',['../structNcTypeInfo_3_01char_01_4.html',1,'']]],
  ['nctypeinfo_3c_20double_20_3e',['NcTypeInfo&lt; double &gt;',['../structNcTypeInfo_3_01double_01_4.html',1,'']]],
  ['nctypeinfo_3c_20float_20_3e',['NcTypeInfo&lt; float &gt;',['../structNcTypeInfo_3_01float_01_4.html',1,'']]],
  ['nctypeinfo_3c_20int_20_3e',['NcTypeInfo&lt; int &gt;',['../structNcTypeInfo_3_01int_01_4.html',1,'']]],
  ['nctypeinfo_3c_20ncbyte_20_3e',['NcTypeInfo&lt; ncbyte &gt;',['../structNcTypeInfo_3_01ncbyte_01_4.html',1,'']]],
  ['nctypestr',['NcTypeStr',['../NetCDFinfo_8h.html#acaac2391dc3d2ffaa3aa5fd7371178c6',1,'NetCDFinfo.h']]],
  ['netcdf_5ftype_5finfo_5fversion',['NETCDF_TYPE_INFO_VERSION',['../NetCDFinfo_8h.html#a770d31ec7fb29f478df84ef533107639',1,'NetCDFinfo.h']]],
  ['netcdfinfo_2eh',['NetCDFinfo.h',['../NetCDFinfo_8h.html',1,'']]],
  ['newcdatagenerator',['NewCDataGenerator',['../classCDataGenerator__factory.html#ab60eba27d948168eace094da8e8a6760',1,'CDataGenerator_factory']]],
  ['newcdataprocessorcpu',['NewCDataProcessorCPU',['../classCDataProcessorCPU__factory.html#a4a58dfc138ec18d1db59eea3fc577a0f',1,'CDataProcessorCPU_factory']]],
  ['newcdataprocessorgpu',['NewCDataProcessorGPU',['../classCDataProcessorGPUfactory.html#a6ffe84fa54b0db0753819f8742d6f061',1,'CDataProcessorGPUfactory']]]
];

var searchData=
[
  ['boost_5fcompute_5ffunction',['BOOST_COMPUTE_FUNCTION',['../classCDataProcessorGPU__function__macro.html#a0b73c6b4f18350c71c6e1ef5f5dcf824',1,'CDataProcessorGPU_function_macro']]]
];

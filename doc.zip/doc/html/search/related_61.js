var searchData=
[
  ['asio_5fhandler_5fallocate',['asio_handler_allocate',['../classudp__server.html#a69acf39d8cd1dc39efa1c33ebdfc57f7',1,'udp_server::asio_handler_allocate()'],['../structudp__server_1_1ref.html#ab4fae963a701d6406629e2e6475ed6a2',1,'udp_server::ref::asio_handler_allocate()']]],
  ['asio_5fhandler_5fdeallocate',['asio_handler_deallocate',['../classudp__server.html#a558cefd26a328abbbcf41e06b200b1f2',1,'udp_server::asio_handler_deallocate()'],['../structudp__server_1_1ref.html#a8206d2bf5207ca489dc56ffa4650ea1d',1,'udp_server::ref::asio_handler_deallocate()']]]
];

var searchData=
[
  ['k',['k',['../classCDataProcessor__Trapeze.html#aedcf479c2850399fd474819f620af767',1,'CDataProcessor_Trapeze::k()'],['../classCDataProcessorGPU__discri__opencl.html#a0835db9fc68fd0fc0f6bd60564b6ee2f',1,'CDataProcessorGPU_discri_opencl::k()']]],
  ['kernel',['kernel',['../classCDataProcessorGPU__opencl.html#a7fa1cb4a7707e6ccefb7de59c8ba8322',1,'CDataProcessorGPU_opencl']]],
  ['kernel_5floaded',['kernel_loaded',['../classCDataProcessorGPU__discri__opencl.html#a613c4d1752e55f2b359b667aef01e879',1,'CDataProcessorGPU_discri_opencl::kernel_loaded()'],['../classCDataProcessorGPU__opencl.html#a123239036180c50a7f3b8a0bd9673c0b',1,'CDataProcessorGPU_opencl::kernel_loaded()'],['../classCDataProcessorGPU__opencl__template.html#a0761afbc0f69f34a031a8447afffaf20',1,'CDataProcessorGPU_opencl_template::kernel_loaded()']]],
  ['kernel_5fname',['kernel_name',['../classCDataProcessorGPU__opencl__template.html#aec1e731f6edb56677516cd3af7b4802a',1,'CDataProcessorGPU_opencl_template']]]
];

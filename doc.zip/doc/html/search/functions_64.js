var searchData=
[
  ['deallocate',['deallocate',['../classallocator.html#a980a959588349c4a8f8dea41ee1b9027',1,'allocator']]],
  ['define_5fopencl_5fsource',['define_opencl_source',['../classCDataProcessorGPU__opencl__template.html#afb4309eeda7a708ac3d8ce748ea75d0f',1,'CDataProcessorGPU_opencl_template::define_opencl_source()'],['../classCDataProcessorGPU__opencl__T4.html#a2e3f9b8f9db77a77b566c96e65927327',1,'CDataProcessorGPU_opencl_T4::define_opencl_source()'],['../classCDataProcessorGPU__opencl__T4xyzw.html#a4076f85b723b83e5aef083b6a6b9e914',1,'CDataProcessorGPU_opencl_T4xyzw::define_opencl_source()'],['../classCDataProcessorGPU__opencl__T4ls__fma.html#acf827772ef768fd6613e607b8888cd5c',1,'CDataProcessorGPU_opencl_T4ls_fma::define_opencl_source()']]],
  ['dim',['dim',['../classCImgNetCDF.html#abfd9f3decfff0f38b656de221bcf0114',1,'CImgNetCDF']]]
];

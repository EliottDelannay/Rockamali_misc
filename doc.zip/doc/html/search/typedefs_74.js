var searchData=
[
  ['taccess',['Taccess',['../receive_8cpp.html#ab8f09024363898e1f0630458aec97b1c',1,'Taccess():&#160;receive.cpp'],['../SDataTypes_8hpp.html#ab8f09024363898e1f0630458aec97b1c',1,'Taccess():&#160;SDataTypes.hpp'],['../send_8cpp.html#ab8f09024363898e1f0630458aec97b1c',1,'Taccess():&#160;send.cpp']]],
  ['tdata',['Tdata',['../receive_8cpp.html#ac58f54bfc5b0f2c8033941080f43190f',1,'Tdata():&#160;receive.cpp'],['../SDataTypes_8hpp.html#ac58f54bfc5b0f2c8033941080f43190f',1,'Tdata():&#160;SDataTypes.hpp'],['../send_8cpp.html#ac58f54bfc5b0f2c8033941080f43190f',1,'Tdata():&#160;send.cpp']]],
  ['tdata2',['Tdata2',['../classCDataProcessorGPU__discri__opencl__int2.html#a2c39c1454c701399f26b0049886d94bf',1,'CDataProcessorGPU_discri_opencl_int2']]],
  ['tdata4',['Tdata4',['../classCDataProcessorGPU__discri__opencl__int4.html#a0496e498ff834af752a3bcdcc3c26d60',1,'CDataProcessorGPU_discri_opencl_int4']]],
  ['tproc',['Tproc',['../receive_8cpp.html#ab189bd6ff342aad5c203f07b4387df21',1,'Tproc():&#160;receive.cpp'],['../SDataTypes_8hpp.html#ab984a958e03556fae474c3c84b7a1712',1,'Tproc():&#160;SDataTypes.hpp']]],
  ['tproc2',['Tproc2',['../classCDataProcessorGPU__discri__opencl__int2.html#a2c1c1c2778b5a58d8b553a47afd8bb7c',1,'CDataProcessorGPU_discri_opencl_int2']]],
  ['tproc4',['Tproc4',['../classCDataProcessorGPU__discri__opencl__int4.html#a971f6cf36c093e6ad4d14a1e0b2e6667',1,'CDataProcessorGPU_discri_opencl_int4']]]
];

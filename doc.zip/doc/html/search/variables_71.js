var searchData=
[
  ['q',['q',['../classCDataProcessor__Trapeze.html#ab50e791cada654970f43d44827efc135',1,'CDataProcessor_Trapeze::q()'],['../classCDataProcessorGPU__discri__opencl.html#a543e630d210aeaebc50cee0a4251c5c0',1,'CDataProcessorGPU_discri_opencl::q()']]],
  ['queue',['queue',['../classCDataProcessorGPU.html#a53351f195dada8dc79e55a0e49cf2c0d',1,'CDataProcessorGPU']]]
];

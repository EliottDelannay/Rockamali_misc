var searchData=
[
  ['a',['A',['../classCDataGenerator__Peak.html#aadb7e699f3cbdf3537bc03cc2848b4eb',1,'CDataGenerator_Peak::A()'],['../classCDataProcessor__Max__Min.html#aa3355741ed4e0b5a9763af3af8db62c5',1,'CDataProcessor_Max_Min::A()']]],
  ['ai',['Ai',['../classCDataProcessor__Max__Min.html#ae8d092ed979cb538ba58cdbbb8e91dee',1,'CDataProcessor_Max_Min']]],
  ['allocator_5f',['allocator_',['../classudp__server.html#ab62f67a0826e4e26f8ab852bc0213764',1,'udp_server']]],
  ['alpha',['alpha',['../classCDataProcessor__Trapeze.html#a764dfcee9737a8b5131299c47c068e5d',1,'CDataProcessor_Trapeze::alpha()'],['../classCDataProcessorGPU__discri__opencl.html#a34e7e0e4552d9c8c004dee939941e566',1,'CDataProcessorGPU_discri_opencl::alpha()']]],
  ['argp',['argp',['../readParameters_8cpp.html#ab70c96531b1b652d70c221cfaf3207f3',1,'readParameters.cpp']]],
  ['argp_5fprogram_5fbug_5faddress',['argp_program_bug_address',['../readParameters_8cpp.html#aaa037e59f26a80a8a2e35e6f2364004d',1,'readParameters.cpp']]],
  ['argp_5fprogram_5fversion',['argp_program_version',['../readParameters_8cpp.html#a62f73ea01c816f1996aed4c66f57c4fb',1,'readParameters.cpp']]],
  ['args_5fdoc',['args_doc',['../readParameters_8cpp.html#a91b08784b3668a8a1fbe2eec1947fb9d',1,'readParameters.cpp']]]
];

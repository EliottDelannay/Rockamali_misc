var searchData=
[
  ['dim',['DIM',['../CImg__NetCDF_8h.html#a0e43a91f1c680c07a96cf618ab4aab38',1,'DIM():&#160;CImg_NetCDF.h'],['../CImg__NetCDF_8h.html#a2efaf9f0dc62007e4e59e5bd0b259450',1,'DIM():&#160;CImg_NetCDF.h']]],
  ['dim_5ferror',['DIM_ERROR',['../NetCDFinfo_8h.html#a32a226e573a6f0d9226fb19655b4eece',1,'DIM_ERROR():&#160;NetCDFinfo.h'],['../CImg__NetCDF_8h.html#a32a226e573a6f0d9226fb19655b4eece',1,'DIM_ERROR():&#160;CImg_NetCDF.h']]]
];
